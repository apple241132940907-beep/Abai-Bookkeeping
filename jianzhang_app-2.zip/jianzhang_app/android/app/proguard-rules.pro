# ============================================================
# ProGuard / R8 規則
# Release 版本啟用 minifyEnabled 後，避免下列必要類別被誤刪或混淆
# ============================================================

# Flutter 引擎本身
-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.**  { *; }
-keep class io.flutter.util.**  { *; }
-keep class io.flutter.view.**  { *; }
-keep class io.flutter.**  { *; }
-keep class io.flutter.plugins.**  { *; }
-dontwarn io.flutter.embedding.**

# webview_flutter
-keep class com.google.android.webview.** { *; }
-keep class android.webkit.** { *; }
-keepclassmembers class * extends android.webkit.WebChromeClient {
    public *;
}

# google_mobile_ads（AdMob）
-keep class com.google.android.gms.ads.** { *; }
-keep public class com.google.android.gms.internal.ads.** { *; }
-dontwarn com.google.android.gms.ads.**

# Google Play Core（動態功能所需，避免 R8 相關 missing class 警告）
-keep class com.google.android.play.core.** { *; }
-dontwarn com.google.android.play.core.**

# permission_handler
-keep class com.baseflow.permissionhandler.** { *; }

# 保留原生方法（JNI）
-keepclasseswithmembernames class * {
    native <methods>;
}

# 保留 Enum 相關方法，避免序列化行為異常
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}
