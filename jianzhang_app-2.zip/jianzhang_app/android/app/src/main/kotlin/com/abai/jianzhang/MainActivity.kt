package com.abai.jianzhang

import io.flutter.embedding.android.FlutterActivity

/**
 * App 唯一的 Android 原生 Activity。
 * 目前沿用 Flutter 預設行為，未來如需與原生層溝通（Platform Channel），
 * 可在此擴充。
 */
class MainActivity : FlutterActivity()
