【App Icon 預留位置】
請將正式 App 圖示放入此資料夾，命名為 app_icon.png
建議尺寸：1024 x 1024 px（正方形、無透明背景邊角會由系統自動裁切）

放入圖檔後，於專案根目錄執行：
  flutter pub get
  flutter pub run flutter_launcher_icons

即會自動產生 Android（mipmap-*）與 iOS（AppIcon.appiconset）各尺寸圖示。
