【Splash Screen 圖檔預留位置】
請將啟動畫面 Logo 放入此資料夾，命名為 splash_logo.png
建議尺寸：512 x 512 px 以上，透明背景 PNG

放入圖檔後，於專案根目錄執行：
  flutter pub get
  flutter pub run flutter_native_splash:create

即會自動產生 Android / iOS 原生啟動畫面設定
（設定內容請見 pubspec.yaml 中的 flutter_native_splash 區塊）。
