import 'package:flutter/material.dart';
import '../core/constants/app_constants.dart';
import '../core/theme/app_theme.dart';
import '../screens/splash/splash_screen.dart';

/// ============================================================
/// App 根元件
///
/// 負責：
/// - 套用 Material Design 3 主題（淺色 / 深色，跟隨系統設定）
/// - 設定 App 標題
/// - 指定啟動時的第一個畫面為 [SplashScreen]
/// ============================================================
class JianZhangApp extends StatelessWidget {
  const JianZhangApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConstants.appName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.system,
      home: const SplashScreen(),
    );
  }
}
