import 'dart:io' show Platform;

/// ============================================================
/// AdMob 廣告單元 ID 管理
///
/// - 3. 目前使用 Google 官方測試 Banner 廣告 ID（可安全用於開發／測試，
///   不會產生無效流量風險）
/// - 4. 正式廣告 ID 預留位置：請於申請 AdMob 帳號並建立正式廣告單元後，
///   將下方 `_androidProdBannerId` / `_iosProdBannerId` 替換為正式 ID，
///   並將 [useProductionAdUnitId] 改為 true 即可切換上線
/// ============================================================
class AdHelper {
  const AdHelper._();

  // -------------------- 測試 Banner 廣告 ID（Google 官方公開測試 ID） --------------------
  static const String _androidTestBannerId =
      'ca-app-pub-3940256099942544/6300978111';
  static const String _iosTestBannerId =
      'ca-app-pub-3940256099942544/2934735716';

  // -------------------- 正式 Banner 廣告 ID（2026 年由使用者於 AdMob 建立） --------------------
  static const String _androidProdBannerId =
      'ca-app-pub-7975215383716582/1416438265';
  static const String _iosProdBannerId =
      'ca-app-pub-XXXXXXXXXXXXXXXX/ZZZZZZZZZZ'; // iOS 版本尚未申請，之後補上

  /// 是否使用正式廣告 ID
  /// 開發／測試階段請保持 false；準備上架時再改為 true
  static const bool useProductionAdUnitId = false;

  /// 依目前執行平台，回傳對應的 Banner 廣告單元 ID
  static String get bannerAdUnitId {
    if (Platform.isAndroid) {
      return useProductionAdUnitId
          ? _androidProdBannerId
          : _androidTestBannerId;
    }
    if (Platform.isIOS) {
      return useProductionAdUnitId ? _iosProdBannerId : _iosTestBannerId;
    }
    // 其他平台（理論上不會發生）：回傳 Android 測試 ID 作為安全預設值
    return _androidTestBannerId;
  }
}
