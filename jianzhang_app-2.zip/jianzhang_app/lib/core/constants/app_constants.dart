/// ============================================================
/// App 全域常數
/// 統一管理 App 名稱、版本相關資訊等，方便日後維護與修改
/// ============================================================
class AppConstants {
  // 避免此類別被實例化
  const AppConstants._();

  /// App 顯示名稱
  static const String appName = '阿白記帳';

  /// App 副標題
  static const String appSlogan = '個人記帳';

  /// Splash Screen 顯示時間（毫秒）
  static const int splashDurationMs = 1200;

  /// WebView 載入的本地 HTML 進入檔案（assets 路徑）
  static const String webAppEntryAsset = 'assets/html/index.html';
}
