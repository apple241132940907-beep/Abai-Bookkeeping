import 'package:flutter/material.dart';

/// ============================================================
/// App 顏色定義
/// 對應原始 HTML/CSS 中 :root 與 [data-theme] 所定義的設計變數，
/// 讓 Flutter 原生外殼（Splash Screen、狀態列等）與 WebView 內容視覺一致
/// ============================================================
class AppColors {
  const AppColors._();

  // -------------------- 淺色模式 --------------------
  static const Color lightBackground = Color(0xFFFBF5EC);
  static const Color lightCard = Color(0xFFFFFFFF);
  static const Color lightText = Color(0xFF3A2E22);
  static const Color lightTextSecondary = Color(0xFF8C7B64);
  static const Color lightSeparator = Color(0xFFEFE4D2);
  static const Color lightAccent = Color(0xFFB8763B);

  // -------------------- 深色模式 --------------------
  static const Color darkBackground = Color(0xFF1E1710);
  static const Color darkCard = Color(0xFF2A2119);
  static const Color darkText = Color(0xFFF5EFE6);
  static const Color darkTextSecondary = Color(0xFFB8A98F);
  static const Color darkSeparator = Color(0xFF3D3122);
  static const Color darkAccent = Color(0xFFD6A15F);

  // -------------------- 通用強調色 --------------------
  static const Color green = Color(0xFF4C9A6A);
  static const Color red = Color(0xFFE2622A);
  static const Color orange = Color(0xFFD98B3F);
  static const Color purple = Color(0xFFB36BD4);
  static const Color yellow = Color(0xFFE8C547);
}
