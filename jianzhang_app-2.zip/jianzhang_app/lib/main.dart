import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

import 'app/app.dart';

/// ============================================================
/// App 進入點
///
/// - 已啟用 Dart Null Safety（見 pubspec.yaml 中 environment 設定）
/// - WidgetsFlutterBinding.ensureInitialized() 確保在 runApp 前
///   即可安全呼叫需要平台通道的初始化程式
/// - 1. 初始化 Google Mobile Ads SDK
///   （以 try-catch 包裹：即使初始化失敗（例如裝置無網路），
///   也不會影響 App 其餘功能正常啟動，對應第四段需求 7）
/// ============================================================
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    await MobileAds.instance.initialize();
  } catch (error) {
    // 7. 廣告初始化失敗不得影響 App 正常運作，僅記錄除錯訊息
    debugPrint('[AdMob] SDK 初始化失敗（不影響 App 運作）：$error');
  }

  runApp(const JianZhangApp());
}
