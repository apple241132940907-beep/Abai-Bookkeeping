import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';
import 'package:webview_flutter_wkwebview/webview_flutter_wkwebview.dart';

import '../../core/ads/ad_helper.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_colors.dart';
import '../../widgets/exit_confirm_dialog.dart';
import 'widgets/webview_error_view.dart';
import 'widgets/webview_loading_view.dart';

/// ============================================================
/// WebView 主畫面
///
/// 負責將 assets/html/index.html（原始 HTML/CSS/JS，內容未經修改）
/// 以 Flutter WebView 呈現，並提供：
/// Loading／錯誤畫面、下拉重新整理、JavaScript 雙向通訊、
/// 深色模式呼應、全螢幕顯示、直向／橫向自動適應、
/// AdMob Banner 廣告、離開確認、檔案下載／圖片上傳／相機拍照。
/// ============================================================
class WebViewScreen extends StatefulWidget {
  const WebViewScreen({super.key});

  @override
  State<WebViewScreen> createState() => _WebViewScreenState();
}

class _WebViewScreenState extends State<WebViewScreen>
    with WidgetsBindingObserver {
  late final WebViewController _controller;

  /// 目前是否正在載入頁面（控制 Loading 畫面顯示/隱藏）
  bool _isLoading = true;

  /// 是否發生載入錯誤（控制錯誤畫面顯示）
  bool _hasError = false;

  /// 錯誤詳細訊息（除錯用）
  String? _errorMessage;

  /// 是否已完成「首次」頁面載入
  /// 用來避免最初載入本地 assets 頁面時，被外部連結攔截邏輯誤判攔截
  bool _initialLoadDone = false;

  /// 目前已載入成功的 Banner 廣告（載入失敗或尚未載入時為 null，
  /// 版面會自動不保留廣告區塊高度，對應第四段需求 6 / 7）
  BannerAd? _bannerAd;

  /// 是否已送出過 Banner 廣告載入請求（避免 didChangeDependencies 重複觸發）
  bool _bannerAdRequested = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    // 進入頁面即啟用全螢幕沉浸模式，讓 WebView 內容有完整可視空間
    _enterImmersiveMode();

    _controller = _createController();
    unawaited(_loadLocalApp());
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // 5. Banner 廣告需要畫面寬度資訊（自適應尺寸），
    // 於 didChangeDependencies 才能安全取得 MediaQuery，故於此觸發載入
    if (!_bannerAdRequested) {
      _bannerAdRequested = true;
      unawaited(_loadBannerAd());
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _bannerAd?.dispose();
    // 離開 WebView 畫面時還原系統 UI 顯示模式
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  void didChangePlatformBrightness() {
    super.didChangePlatformBrightness();
    // 系統深色/淺色模式切換時，同步更新 WebView 底色，避免視覺閃爍
    _syncBackgroundColorWithBrightness();
  }

  /// 進入沉浸式全螢幕模式（隱藏狀態列與導覽列，滑動可暫時喚出）
  void _enterImmersiveMode() {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  /// 依目前系統亮度，將 WebView 底色設為對應主題背景色
  void _syncBackgroundColorWithBrightness() {
    final Brightness brightness =
        WidgetsBinding.instance.platformDispatcher.platformBrightness;
    final Color bg = brightness == Brightness.dark
        ? AppColors.darkBackground
        : AppColors.lightBackground;
    unawaited(_controller.setBackgroundColor(bg));
  }

  // ============================================================
  // 1. & 5. & 6. & 7. AdMob Banner 廣告
  // ============================================================

  /// 載入 Banner 廣告
  ///
  /// 使用標準 320x50 固定尺寸（非自適應大橫幅），
  /// 盡量把畫面高度還給 WebView，避免壓縮到網頁內部固定版面
  /// （例如新增交易畫面的數字鍵盤）的可用空間。
  ///
  /// 7. 任何載入失敗情況皆被攔截處理，只會讓廣告區塊不顯示，
  /// 不會拋出例外或影響 WebView 主功能運作。
  Future<void> _loadBannerAd() async {
    try {
      const AdSize bannerSize = AdSize.banner;

      final BannerAd bannerAd = BannerAd(
        adUnitId: AdHelper.bannerAdUnitId,
        size: bannerSize,
        request: const AdRequest(),
        listener: BannerAdListener(
          onAdLoaded: (Ad ad) {
            if (!mounted) {
              ad.dispose();
              return;
            }
            setState(() {
              _bannerAd = ad as BannerAd;
            });
          },
          onAdFailedToLoad: (Ad ad, LoadAdError error) {
            // 7. 廣告載入失敗：僅記錄除錯訊息並釋放資源，
            // 版面自動不保留廣告高度，App 其餘功能不受影響
            debugPrint('[AdMob] Banner 廣告載入失敗：$error');
            ad.dispose();
            if (mounted) {
              setState(() {
                _bannerAd = null;
              });
            }
          },
        ),
      );

      await bannerAd.load();
    } catch (error) {
      // 7. 例外情況（例如裝置無網路、AdMob 服務異常）同樣不得影響 App
      debugPrint('[AdMob] Banner 廣告初始化例外：$error');
    }
  }

  // ============================================================
  // WebViewController 建立與設定
  // ============================================================

  /// 建立並設定 WebViewController
  WebViewController _createController() {
    late final PlatformWebViewControllerCreationParams params;
    if (WebViewPlatform.instance is WebKitWebViewPlatform) {
      params = WebKitWebViewControllerCreationParams(
        allowsInlineMediaPlayback: true,
        mediaTypesRequiringUserAction: const <PlaybackMediaTypes>{},
      );
    } else {
      params = const PlatformWebViewControllerCreationParams();
    }

    final WebViewController controller =
        WebViewController.fromPlatformCreationParams(params);

    controller
      // 啟用 JavaScript（unrestricted 模式允許頁面完整執行原始 JS）
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(AppColors.lightBackground)
      // 15. JavaScript ↔ Flutter 雙向通訊管道
      // 網頁端可透過 `FlutterBridge.postMessage(...)` 呼叫 Flutter 原生功能，
      // 支援傳入純文字，或 JSON 字串（{"action": "...", ...}）以呼叫
      // 特定原生功能（分享 App、開啟外部網址、檔案下載等）
      ..addJavaScriptChannel(
        'FlutterBridge',
        onMessageReceived: _handleJavaScriptMessage,
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (String url) {
            if (!mounted) {
              return;
            }
            setState(() {
              _isLoading = true;
              _hasError = false;
            });
          },
          onPageFinished: (String url) {
            if (!mounted) {
              return;
            }
            setState(() {
              _isLoading = false;
              _initialLoadDone = true;
            });
            // 12. 注入「下載攔截」輔助腳本（僅透過 Controller 於執行期
            // 附加額外行為，不修改 assets/html/index.html 原始檔案內容）
            unawaited(_controller.runJavaScript(_downloadInterceptScript));
          },
          onWebResourceError: (WebResourceError error) {
            if (!mounted) {
              return;
            }
            setState(() {
              _isLoading = false;
              _hasError = true;
              _errorMessage = '${error.errorType ?? ''} ${error.description}'
                  .trim();
            });
          },
          // 11. WebView 最佳化：外部連結（http/https）改以系統瀏覽器開啟
          onNavigationRequest: (NavigationRequest request) {
            if (!_initialLoadDone) {
              return NavigationDecision.navigate;
            }

            final Uri uri = Uri.parse(request.url);
            final bool isExternalHttpLink =
                uri.scheme == 'http' || uri.scheme == 'https';

            if (isExternalHttpLink) {
              unawaited(_openExternalLink(uri));
              return NavigationDecision.prevent;
            }

            return NavigationDecision.navigate;
          },
        ),
      );

    if (controller.platform is AndroidWebViewController) {
      final AndroidWebViewController androidController =
          controller.platform as AndroidWebViewController;

      // 啟用 Local Storage / DOM Storage
      androidController.setDomStorageEnabled(true);

      // 支援 Console Log
      androidController.setOnConsoleMessage(
        (AndroidWebViewConsoleMessage message) {
          debugPrint('[WebView Console] ${message.message}');
        },
      );

      if (kDebugMode) {
        AndroidWebViewController.enableDebugging(true);
      }

      androidController.setMediaPlaybackRequiresUserGesture(false);

      // 13. & 14. HTML 圖片上傳／相機拍照（input type="file"）
      // Android 需明確註冊檔案選取器回呼，才能彈出選單並開啟相機／相簿
      unawaited(androidController.setOnShowFileSelector(_androidFilePicker));
    } else if (controller.platform is WebKitWebViewController) {
      final WebKitWebViewController iosController =
          controller.platform as WebKitWebViewController;
      // iOS（WKWebView，iOS 15+）針對 <input type="file">（含 capture
      // 屬性的相機拍照）已原生內建檔案／相機選擇彈窗，不需額外實作，
      // 僅需於 Info.plist 提供 NSCameraUsageDescription /
      // NSPhotoLibraryUsageDescription 使用說明文字（已於第三段完成）。
      unawaited(iosController.setAllowsBackForwardNavigationGestures(true));
    }

    // Cookie 支援：Android WebView 與 iOS WKWebView 皆預設啟用 Cookie

    return controller;
  }

  /// 13. & 14. Android 檔案選取器回呼
  ///
  /// 註：`FileSelectorParams` 目前公開穩定的欄位僅有 `acceptTypes` /
  /// `mode`，並未提供可直接判斷 HTML `capture` 屬性的旗標，因此改用
  /// 更穩妥的做法：彈出「拍照」／「從相簿選擇」選單交由使用者決定，
  /// 同時滿足需求 13（圖片上傳）與需求 14（相機拍照）。
  Future<List<String>> _androidFilePicker(FileSelectorParams params) async {
    try {
      final ImageSource? source = await _pickImageSource();
      if (source == null) {
        return <String>[];
      }

      final ImagePicker picker = ImagePicker();
      final XFile? file =
          await picker.pickImage(source: source, imageQuality: 90);

      if (file == null) {
        return <String>[];
      }
      return <String>[Uri.file(file.path).toString()];
    } catch (error) {
      debugPrint('[WebViewScreen] 檔案選擇發生錯誤：$error');
      return <String>[];
    }
  }

  /// 顯示「拍照」／「從相簿選擇」選單（Material Design 3 風格底部選單）
  Future<ImageSource?> _pickImageSource() async {
    if (!mounted) {
      return null;
    }
    return showModalBottomSheet<ImageSource>(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (BuildContext sheetContext) {
        return SafeArea(
          child: Wrap(
            children: <Widget>[
              ListTile(
                leading: const Icon(Icons.photo_camera_rounded),
                title: const Text('拍照'),
                onTap: () =>
                    Navigator.of(sheetContext).pop(ImageSource.camera),
              ),
              ListTile(
                leading: const Icon(Icons.photo_library_rounded),
                title: const Text('從相簿選擇'),
                onTap: () =>
                    Navigator.of(sheetContext).pop(ImageSource.gallery),
              ),
            ],
          ),
        );
      },
    );
  }

  /// 載入本地 HTML（assets/html/index.html），內容維持原樣未經修改
  Future<void> _loadLocalApp() async {
    setState(() {
      _isLoading = true;
      _hasError = false;
      _initialLoadDone = false;
    });

    _syncBackgroundColorWithBrightness();

    try {
      await _controller.loadFlutterAsset(AppConstants.webAppEntryAsset);
    } on PlatformException catch (e) {
      if (!mounted) {
        return;
      }
      setState(() {
        _isLoading = false;
        _hasError = true;
        _errorMessage = e.message;
      });
    }
  }

  /// 重新整理：重新載入本地 HTML
  Future<void> _reload() async {
    await _loadLocalApp();
  }

  /// 11. 以系統瀏覽器開啟外部連結
  Future<void> _openExternalLink(Uri uri) async {
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      debugPrint('[WebViewScreen] 無法開啟外部連結：$uri');
    }
  }

  /// 10. 分享 App
  Future<void> _shareApp() async {
    // 上架後請將下方文字替換為正式的 Google Play / App Store 連結
    await SharePlus.instance.share(
      ShareParams(
        text: '推薦你使用「${AppConstants.appName}」——${AppConstants.appSlogan}！\n'
            '（App 上架連結請於發佈後補上）',
      ),
    );
  }

  // ============================================================
  // 15. JavaScript ↔ Flutter 雙向通訊
  // ============================================================

  /// 處理來自網頁端（JavaScript）傳來的訊息
  ///
  /// 支援兩種格式：
  /// - 純文字：僅記錄於除錯輸出
  /// - JSON 字串：`{"action": "shareApp"}` /
  ///   `{"action": "openExternal", "url": "https://..."}` /
  ///   `{"action": "download", "filename": "...", "data": "<base64>"}`
  void _handleJavaScriptMessage(JavaScriptMessage message) {
    final String raw = message.message;
    debugPrint('[FlutterBridge] 收到網頁訊息：$raw');

    Map<String, dynamic>? payload;
    try {
      final dynamic decoded = jsonDecode(raw);
      if (decoded is Map<String, dynamic>) {
        payload = decoded;
      }
    } catch (_) {
      // 非 JSON 格式，視為一般文字訊息，僅記錄即可
      return;
    }

    if (payload == null) {
      return;
    }

    final String action = payload['action']?.toString() ?? '';

    if (action == 'shareApp') {
      unawaited(_shareApp());
    } else if (action == 'openExternal') {
      final String? url = payload['url']?.toString();
      if (url != null && url.isNotEmpty) {
        unawaited(_openExternalLink(Uri.parse(url)));
      }
    } else if (action == 'download') {
      final String filename = payload['filename']?.toString() ?? 'download';
      final String data = payload['data']?.toString() ?? '';
      if (data.isNotEmpty) {
        unawaited(_handleDownload(filename, data));
      }
    } else {
      debugPrint('[FlutterBridge] 未知的 action：$action');
    }
  }

  /// 12. 處理 HTML 檔案下載
  /// 將網頁端傳來的 Base64 檔案內容寫入 App 文件目錄，
  /// 並開啟系統分享面板，讓使用者選擇儲存位置（Files App／雲端硬碟／傳送等）。
  Future<void> _handleDownload(String filename, String base64Data) async {
    try {
      final Uint8List bytes = base64Decode(base64Data);
      final Directory dir = await getApplicationDocumentsDirectory();
      final String safeName = _sanitizeFilename(filename);
      final File file = File('${dir.path}/$safeName');
      await file.writeAsBytes(bytes, flush: true);

      if (!mounted) {
        return;
      }

      await SharePlus.instance.share(
        ShareParams(
          files: <XFile>[XFile(file.path)],
          text: '${AppConstants.appName} 匯出檔案',
        ),
      );
    } catch (error) {
      debugPrint('[WebViewScreen] 檔案下載處理失敗：$error');
      if (!mounted) {
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('檔案下載失敗，請再試一次')),
      );
    }
  }

  String _defaultDownloadFilename() {
    return 'download_${DateTime.now().millisecondsSinceEpoch}';
  }

  /// 淨化檔名：僅保留檔名本身（去除路徑分隔符與上層目錄符號），
  /// 避免寫入路徑被導向文件目錄以外的位置（防禦性安全處理）
  String _sanitizeFilename(String rawFilename) {
    final String trimmed = rawFilename.trim();
    if (trimmed.isEmpty) {
      return _defaultDownloadFilename();
    }
    // 僅取路徑最後一段，並移除任何殘留的路徑分隔符
    final String base = trimmed.split(RegExp(r'[\\/]')).last.trim();
    final String cleaned = base.replaceAll('..', '');
    return cleaned.isEmpty ? _defaultDownloadFilename() : cleaned;
  }

  /// 允許 Flutter 端主動呼叫網頁 JavaScript 函式的輔助方法
  Future<void> callJavaScript(String script) async {
    await _controller.runJavaScript(script);
  }

  // ============================================================
  // 8. & 9. Android 返回鍵：優先返回 WebView 上一頁，否則詢問是否離開
  // ============================================================

  Future<void> _handleBackNavigation() async {
    if (await _controller.canGoBack()) {
      await _controller.goBack();
      return;
    }

    if (!mounted) {
      return;
    }

    final bool shouldExit = await showExitConfirmDialog(context);
    if (shouldExit && mounted) {
      SystemNavigator.pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final double? bannerHeight = _bannerAd?.size.height.toDouble();

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (bool didPop, Object? result) async {
        if (didPop) {
          return;
        }
        await _handleBackNavigation();
      },
      child: Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        // 已啟用全螢幕沉浸模式（系統列預設隱藏），故上方不需要保留
        // SafeArea 空間；僅保留下方安全邊界，避免手勢導覽列與 Banner
        // 廣告重疊，盡量把可用高度還給 WebView（修正版面被壓縮的問題）
        body: SafeArea(
          top: false,
          child: Column(
            children: <Widget>[
              // 主要內容區：WebView + Loading + 錯誤畫面 + 常駐按鈕
              // 6. 使用 Expanded 讓 WebView 自動扣除下方 Banner 廣告高度，
              // 版面永遠完整，不會被廣告遮住
              Expanded(
                child: Stack(
                  children: <Widget>[
                    if (!_hasError) WebViewWidget(controller: _controller),

                    AnimatedOpacity(
                      opacity: (_isLoading && !_hasError) ? 1 : 0,
                      duration: const Duration(milliseconds: 250),
                      curve: Curves.easeOut,
                      child: IgnorePointer(
                        ignoring: !(_isLoading && !_hasError),
                        child: const WebViewLoadingView(),
                      ),
                    ),

                    if (_hasError)
                      WebViewErrorView(
                        message: _errorMessage,
                        onRetry: _reload,
                      ),

                    if (!_hasError)
                      Positioned(
                        top: 8,
                        right: 8,
                        child: _ActionButtonBar(
                          onReload: _reload,
                          onShare: _shareApp,
                        ),
                      ),
                  ],
                ),
              ),

              // 5. & 6. & 7. Banner 廣告固定顯示於畫面最下方
              // 僅在成功載入時才保留高度；載入失敗／尚未載入時完全不佔版面
              if (_bannerAd != null && bannerHeight != null)
                Container(
                  width: double.infinity,
                  height: bannerHeight,
                  alignment: Alignment.center,
                  color: Theme.of(context).scaffoldBackgroundColor,
                  child: AdWidget(ad: _bannerAd!),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

/// 常駐操作按鈕列（重新整理／分享 App），半透明、不干擾網頁內容操作
class _ActionButtonBar extends StatelessWidget {
  const _ActionButtonBar({
    required this.onReload,
    required this.onShare,
  });

  final VoidCallback onReload;
  final VoidCallback onShare;

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    final Color bg = (isDark ? AppColors.darkCard : AppColors.lightCard)
        .withValues(alpha: 0.72);
    final Color fg = isDark ? AppColors.darkText : AppColors.lightText;

    return Material(
      color: bg,
      borderRadius: BorderRadius.circular(24),
      elevation: 1,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          _ActionIconButton(icon: Icons.refresh_rounded, color: fg, onTap: onReload),
          Container(width: 1, height: 20, color: fg.withValues(alpha: 0.15)),
          _ActionIconButton(icon: Icons.ios_share_rounded, color: fg, onTap: onShare),
        ],
      ),
    );
  }
}

class _ActionIconButton extends StatelessWidget {
  const _ActionIconButton({
    required this.icon,
    required this.color,
    required this.onTap,
  });

  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Icon(icon, size: 20, color: color),
      ),
    );
  }
}

/// ============================================================
/// 下載攔截輔助腳本（於 WebView 執行期以 runJavaScript 注入）
///
/// 注意：此腳本僅在「執行期由 Flutter 動態附加」到已載入的頁面上，
/// 完全不會修改 assets/html/index.html 這個原始檔案的任何內容。
///
/// 作用：攔截頁面上帶有 `download` 屬性或 `blob:` / `data:` 網址的
/// 連結點擊事件，改為讀取其內容並透過 FlutterBridge 傳給 Flutter，
/// 由原生端負責寫入檔案並開啟系統分享面板（對應需求 12：HTML 檔案下載）。
/// ============================================================
const String _downloadInterceptScript = r'''
(function () {
  if (window.__flutterDownloadHookInstalled) { return; }
  window.__flutterDownloadHookInstalled = true;

  document.addEventListener('click', function (event) {
    var target = event.target && event.target.closest ? event.target.closest('a') : null;
    if (!target) { return; }

    var href = target.getAttribute('href') || '';
    var hasDownloadAttr = target.hasAttribute('download');
    var isBlobHref = href.indexOf('blob:') === 0;
    var isDataHref = href.indexOf('data:') === 0;

    if (!hasDownloadAttr && !isBlobHref && !isDataHref) { return; }

    event.preventDefault();
    var filename = target.getAttribute('download') || 'download';

    function postToFlutter(base64) {
      if (window.FlutterBridge && window.FlutterBridge.postMessage) {
        window.FlutterBridge.postMessage(JSON.stringify({
          action: 'download',
          filename: filename,
          data: base64
        }));
      }
    }

    if (isDataHref) {
      var commaIndex = href.indexOf(',');
      postToFlutter(commaIndex >= 0 ? href.substring(commaIndex + 1) : '');
      return;
    }

    fetch(href)
      .then(function (res) { return res.blob(); })
      .then(function (blob) {
        var reader = new FileReader();
        reader.onloadend = function () {
          var result = String(reader.result || '');
          var commaIndex = result.indexOf(',');
          postToFlutter(commaIndex >= 0 ? result.substring(commaIndex + 1) : '');
        };
        reader.readAsDataURL(blob);
      })
      .catch(function (err) {
        console.log('[FlutterDownloadHook] fetch failed', err);
      });
  }, true);
})();
''';
