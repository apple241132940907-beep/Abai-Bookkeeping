import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';

/// ============================================================
/// 錯誤頁面
///
/// 當 WebView 載入失敗（例如本地資源讀取異常）時顯示，
/// 提供清楚的錯誤說明與「重新整理」按鈕。
/// ============================================================
class WebViewErrorView extends StatelessWidget {
  const WebViewErrorView({
    required this.onRetry,
    super.key,
    this.message,
  });

  /// 使用者點擊重試按鈕時呼叫
  final VoidCallback onRetry;

  /// 錯誤詳細訊息（選填，供除錯使用）
  final String? message;

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    final Color bg = isDark ? AppColors.darkBackground : AppColors.lightBackground;
    final Color card = isDark ? AppColors.darkCard : AppColors.lightCard;
    final Color accent = isDark ? AppColors.darkAccent : AppColors.lightAccent;
    final Color text = isDark ? AppColors.darkText : AppColors.lightText;
    final Color textSecondary =
        isDark ? AppColors.darkTextSecondary : AppColors.lightTextSecondary;

    return Container(
      color: bg,
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Container(
            width: 84,
            height: 84,
            decoration: BoxDecoration(
              color: card,
              shape: BoxShape.circle,
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.08),
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Icon(
              Icons.wifi_off_rounded,
              size: 38,
              color: AppColors.red,
            ),
          ),
          const SizedBox(height: 24),
          Text(
            '頁面載入失敗',
            style: TextStyle(
              fontSize: 19,
              fontWeight: FontWeight.w600,
              color: text,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '請檢查裝置狀態後再試一次',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 14, color: textSecondary),
          ),
          if (message != null && message!.isNotEmpty) ...<Widget>[
            const SizedBox(height: 4),
            Text(
              message!,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12, color: textSecondary),
            ),
          ],
          const SizedBox(height: 28),
          FilledButton.icon(
            onPressed: onRetry,
            style: FilledButton.styleFrom(
              backgroundColor: accent,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            icon: const Icon(Icons.refresh_rounded),
            label: const Text('重新整理'),
          ),
        ],
      ),
    );
  }
}
