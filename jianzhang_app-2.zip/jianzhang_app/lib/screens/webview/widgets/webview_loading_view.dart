import 'package:flutter/material.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/theme/app_colors.dart';

/// ============================================================
/// Loading 畫面
///
/// 於 WebView 載入本地 HTML 期間顯示，
/// WebView 的 onPageFinished 觸發後由外層淡出隱藏。
/// ============================================================
class WebViewLoadingView extends StatelessWidget {
  const WebViewLoadingView({super.key});

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    final Color bg = isDark ? AppColors.darkBackground : AppColors.lightBackground;
    final Color card = isDark ? AppColors.darkCard : AppColors.lightCard;
    final Color accent = isDark ? AppColors.darkAccent : AppColors.lightAccent;
    final Color text = isDark ? AppColors.darkText : AppColors.lightText;
    final Color textSecondary =
        isDark ? AppColors.darkTextSecondary : AppColors.lightTextSecondary;

    return Container(
      color: bg,
      alignment: Alignment.center,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          // 品牌圖示卡片
          Container(
            width: 88,
            height: 88,
            decoration: BoxDecoration(
              color: card,
              borderRadius: BorderRadius.circular(22),
              boxShadow: <BoxShadow>[
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.08),
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Icon(
              Icons.account_balance_wallet_rounded,
              size: 42,
              color: accent,
            ),
          ),
          const SizedBox(height: 24),

          // 自訂樣式的載入指示器（呼應 accent 主題色，而非系統預設樣式）
          SizedBox(
            width: 28,
            height: 28,
            child: CircularProgressIndicator(
              strokeWidth: 2.6,
              valueColor: AlwaysStoppedAnimation<Color>(accent),
            ),
          ),
          const SizedBox(height: 20),

          Text(
            AppConstants.appName,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: text,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            '載入中…',
            style: TextStyle(
              fontSize: 13,
              color: textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}
