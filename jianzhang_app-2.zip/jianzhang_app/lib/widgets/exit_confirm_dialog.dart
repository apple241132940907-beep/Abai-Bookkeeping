import 'package:flutter/material.dart';
import '../core/constants/app_constants.dart';
import '../core/theme/app_colors.dart';

/// ============================================================
/// 離開 App 確認對話框
///
/// 於 Android 返回鍵在 WebView 已無上一頁可返回時顯示，
/// 避免使用者不小心誤觸返回鍵而直接關閉 App。
///
/// 回傳 true 表示使用者確認離開，false（含取消／點擊外部關閉）表示不離開。
/// ============================================================
Future<bool> showExitConfirmDialog(BuildContext context) async {
  final bool isDark = Theme.of(context).brightness == Brightness.dark;
  final Color accent = isDark ? AppColors.darkAccent : AppColors.lightAccent;

  final bool? result = await showDialog<bool>(
    context: context,
    builder: (BuildContext dialogContext) {
      return AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        icon: Icon(Icons.logout_rounded, color: accent),
        title: const Text('離開 App？'),
        content: Text('確定要離開${AppConstants.appName}嗎？'),
        actionsAlignment: MainAxisAlignment.spaceBetween,
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('取消'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: accent,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('離開'),
          ),
        ],
      );
    },
  );

  return result ?? false;
}
