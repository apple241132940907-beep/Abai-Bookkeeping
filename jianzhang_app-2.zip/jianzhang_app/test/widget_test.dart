import 'package:flutter_test/flutter_test.dart';

import 'package:jianzhang_app/app/app.dart';

void main() {
  testWidgets('App 可正常啟動並顯示 Splash Screen', (WidgetTester tester) async {
    await tester.pumpWidget(const JianZhangApp());

    // Splash Screen 顯示期間，畫面上應可看到 App 名稱文字
    expect(find.text('阿白記帳'), findsOneWidget);
  });
}
